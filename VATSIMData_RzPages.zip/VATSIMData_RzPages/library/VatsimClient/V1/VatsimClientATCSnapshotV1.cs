namespace VatsimLibrary.VatsimClientV1
{
    public class VatsimClientATCSnapshotV1
    {
        
    }

}